# 部署说明（给 AI 看的）

> 你收到的是一个自包含的小服务。任务只有一件：**把它跑起来，让公网能访问，然后把「地址」和「令牌」两样东西交回去。**

---

## 一、这是什么

`server.py` 是一个**工作区服务**，v2。它给 AI 的不是一个裸 shell，而是一套结构化工具：

| 工具 | 端点 | 用途 |
|---|---|---|
| `read_file` | `POST /fs/read` | 按行分段读 |
| `write_file` | `POST /fs/write` | 整篇覆盖写 |
| `edit_file` | `POST /fs/edit` | 单处替换（服务端校验唯一性） |
| `patch_file` | `POST /fs/patch` | **多处替换一次落盘**，全成或全不成 |
| `search_content` | `POST /fs/grep` | 内容搜索，带行号 / 上下文 / glob 过滤 |
| `find_files` | `POST /fs/glob` | 按文件名找，支持 `**` |
| `list_dir` | `POST /fs/list` | 列目录 |
| `run_shell` | `POST /exec` | 执行命令，可选 `sudo` |
| `env_info` | `POST /sys/info` | 发行版 / 用户 / 能否提权 / 装了哪些命令 |
| `install_packages` | `POST /sys/install` | apt / pip / npm 安装，可自动切清华源 |

另外还有 `POST /fs/tree`（浅层目录树）、`/fs/stat`、`/fs/mkdir`、`/fs/remove`、`/fs/move`。

## 传文件（客户端「上传」按钮走的就是这条）

| 接口 | 方法 | 说明 |
| --- | --- | --- |
| `/fs/upload?dir=<目录>&name=<文件名>` | `POST` | 请求体是**原始字节**，不是 JSON。单次上限 256 MiB |
| `/fs/download?path=<文件>` | `GET` | 原样下载，带 `Content-Disposition` |

```bash
# 上传（--data-binary 才不会改动字节）
curl -X POST https://<你的地址>/fs/upload?dir=assets\&name=logo.png \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/octet-stream" \
  --data-binary @logo.png

# 下载
curl -H "Authorization: Bearer $TOKEN" \
  "https://<你的地址>/fs/download?path=assets/logo.png" -o logo.png
```

为什么要 raw body 而不是 base64：手机上传的多半是图片、APK、压缩包，
base64 会多带 33% 的流量与内存。服务端**边收边写**到 `.part`，收完再 rename，
所以传到一半断网不会留下一个看起来正常的半截文件。

文件名只取最后一段并挡掉 `..` / 路径分隔符；越界的 `dir` 会被拒（同所有 `/fs/*`）。

**`GET /tools` 会把这十个工具连同 JSON Schema 一起吐出来** —— 格式是 OpenAI / Anthropic / MCP 通用的那套。任何客户端拿到就能直接用，不需要读这份文档：

```bash
curl -s http://127.0.0.1:3000/tools -H "Authorization: Bearer <令牌>" | python3 -m json.tool
```

用户手机上的 DSHA 客户端会连它，把那台机器当成"云端工作区"。

**不需要的能力一个都没有**：不装数据库、不装 Node、不用 Docker、不用框架。只要机器上有 `python3`（3.8+），标准库就够了。

> 为什么不是"给个 shell 让 AI 自己 grep"：AI 写出的 `grep -rn --include='*.py'` 在 GNU 与 busybox 上行为不一致，写错时返回 0 行，它会当成"确实没有"然后开始凭印象改代码。结构化端点把这类失败变成了一句明确的报错。

## 二、你要交付什么

最后必须明确给出**两样东西**，缺一不可：

```
地址：https://<域名或IP>/            ← 用户能从这里访问到服务根路径
令牌：<32 字节的随机串>
```

- **地址**必须是**公网可访问的根地址**。如果服务挂在子路径下（例如 `https://x.com/dsha/`），地址就写带子路径的那个。
- **令牌**在服务启动日志里会打印成一行 `令牌 : xxxxx`，也在 `token.txt` 里。
- **地址必须是常驻的。** 临时隧道（Cloudflare Quick Tunnel、ngrok 免费版）重启即换域名，只能用于当场验证，不是可交付的地址。实在只能这么做，也必须写明"这个地址在重启后会变"。

顺便告诉用户：工作区目录落在哪台机器的哪个路径。

## 三、先看环境（不要跳过）

```bash
python3 --version                      # 需要 3.8+
uname -a                               # Linux/macOS
```

判断走哪条路，**从上往下取第一条能走通的**：

| 情况 | 走第几节 |
|---|---|
| **你自己具备发布 / 托管能力**（能把一个单端口 HTTP 服务挂到公网） | **四-A：直接发布** ← 首选 |
| 目标机器本身有公网 IP、能开端口 | **四-B：直接跑 + 反向代理** |
| 在 Railway / Render / Fly 这类容器平台 | **四-C：容器托管** |
| 以上都不成立 | **四-D：临时隧道**（只用于当场验证，不作为交付地址） |

## 四-A、直接发布（首选）

**只要你具备"把服务发布到公网"的能力，就用它，不要绕隧道。**

`server.py` 是最容易托管的那类服务：单端口、纯标准库、无数据库、无外网依赖，
工作区就是一个目录。任何能吃单端口 HTTP 服务的托管方式都能直接跑起来：

- **自带发布能力的 Agent / 工作台**：直接发布这个服务，拿平台分配的 HTTPS 域名；
- 容器托管：Railway / Render / Fly.io / Zeabur / 腾讯云云托管 / 阿里云函数计算；
- 自己的服务器 + 反向代理（见四-B）。

步骤：

1. 入口文件 `server.py`，启动命令 `python3 server.py`；
2. 环境变量按平台要求设：`PORT`（多数平台自动注入，服务会读）、
   `DSHA_ROOT`（工作区目录）、`DSHA_TOKEN`（固定令牌）；
3. 平台一般会自动分配 HTTPS 域名 —— **交付地址就是那个域名根路径**，不要带 `/exec`；
4. 按第五节验收，然后按第六节回话。

> **令牌要固定。** 不设 `DSHA_TOKEN` 时服务会在首次启动随机生成并写进 `token.txt`；
> 平台用临时磁盘的话，重启后文件消失、令牌跟着换，用户每次都要重新填一次。
> 要么把这个变量设进平台的环境变量，要么在交付说明里明确写"重启后令牌会变"。

## 四-B、直接跑 + 反向代理（有公网 IP）

1. 放好文件：

   ```bash
   mkdir -p /opt/dsha-cloud && cd /opt/dsha-cloud
   # 把 server.py、run.sh 放进来
   chmod +x run.sh
   ```

2. 启动（后台）：

   ```bash
   DSHA_ROOT=/opt/dsha-cloud/workspace nohup ./run.sh > /dev/null 2>&1 &
   tail -n 20 service.log        # 应看到 "DSHA 云端工作区已启动" 和令牌
   ```

3. **一定要挂 HTTPS**。裸 `http://IP:3000` 在移动网络上经常被中间设备改坏，而且令牌会明文传输。

   用 Caddy（最省事，自动申请证书）：

   ```bash
   # /etc/caddy/Caddyfile
   dsha.example.com {
       reverse_proxy 127.0.0.1:3000
   }
   ```

   ```bash
   systemctl reload caddy
   ```

   没有域名只有 IP → 用 `http://IP:3000` 也可以，但要把这一条**写进交付说明**里，让用户知道是明文传输。

4. 地址就是 `https://dsha.example.com/`（**结尾带不带斜杠都行，但不要带 `/exec`**）。

### 关于 root / sudo（可选，建议开）

客户端里「run_shell」有一个 `privileged` 参数，代表"这条命令要以 root 跑"。
它是**高风险动作**：客户端会在执行前弹一次审批，用户点了允许才发过来。
服务端这一侧要做的只有一件事 —— 让它有权限：

- **服务本身以 root 跑**（最简单）：命令天生就是 root，不额外套 `sudo`。
- **服务以普通用户跑**：给这个用户配免密 sudo

  ```bash
  # 换成实际运行服务的用户，比如 www-data / ubuntu
  echo 'ubuntu ALL=(ALL) NOPASSWD:ALL' | sudo tee /etc/sudoers.d/dsha
  sudo chmod 440 /etc/sudoers.d/dsha
  ```

两种情况都跑一下自检，确认服务自己认得清：

```bash
curl -s -X POST http://127.0.0.1:3000/sys/info \
  -H "Authorization: Bearer <令牌>" -d '{}' | python3 -m json.tool
# 期望看到 "root": true，或 "sudo": true
```

如果两者都是 false，`/exec` 带 `sudo: true` 会返回 403 并说明原因 ——
这是**故意的**：静默降级会让模型以为"命令跑了只是没输出"，白烧好几轮。

> 安全提醒：能给 root 的令牌，等于那台机器的钥匙。令牌别贴进公开的日志、
> 别放进聊天记录；不用的环境及时在客户端里删掉。

## 四-C、容器平台

`server.py` 监听 `0.0.0.0:$PORT`，直接吃平台注入的 `PORT` 环境变量。
启动命令填：

```
python3 server.py
```

注意两点：

- **平台的临时磁盘会在重启后清空** → 令牌会重新生成。要么把 `DSHA_TOKEN` 设成平台的环境变量固定下来，要么接受"重启后要重新填一次令牌"。
- 平台一般会自动给 HTTPS 域名，直接用。

## 四-D、临时隧道（只用于当场验证）

**这不是交付方案。** 只有用户明确说"我现在就要连一下试试"时才用；
用了就必须在回话里写清"地址是临时的、进程一停就失效"。

Cloudflare Quick Tunnel：

```bash
cloudflared tunnel --url http://127.0.0.1:3000
# 输出里会有 https://xxxx-xxxx.trycloudflare.com
```

ngrok：

```bash
ngrok http 3000
# 输出里会有 https://xxxx.ngrok-free.app
```

地址取隧道给的域名，**不要加任何路径**。

> 为什么不推荐：Quick Tunnel / ngrok 免费版给的是随机域名，隧道进程一停就失效。
> 用户把这个地址填进手机客户端，第二天打开就是连接失败 —— 而他只会认为客户端坏了。
> 有发布能力就直接发布（四-A）；没有就换一台有公网入口的机器，或者走容器平台（四-C）。

## 五、验收（这一步必须做）

在**另一台机器**（或至少用公网地址而不是 127.0.0.1）执行：

```bash
# 1) 探活，不需要令牌
curl -sS https://<你的地址>/

# 2) 看工具清单
curl -sS https://<你的地址>/tools -H "Authorization: Bearer <令牌>" | head -c 400

# 3) 带令牌跑一条命令
curl -sS -X POST https://<你的地址>/exec \
  -H "Authorization: Bearer <令牌>" \
  -H "X-Exec-Token: <令牌>" \
  -H "Content-Type: application/json" \
  --data-binary '{"cmd":"echo hello && pwd"}'

# 4) 试一次内容搜索（v2 新增，最该验的一条）
curl -sS -X POST https://<你的地址>/fs/grep \
  -H "Authorization: Bearer <令牌>" \
  -H "Content-Type: application/json" \
  --data-binary '{"pattern":"hello","max":5}'
```

第 3 条必须返回 `{"stdout": "hello\n/...\n", ..., "exit_code": 0}`。
第 4 条必须返回 `{"matches": [...], "files": [...], "files_scanned": N}`；返回 `404` 说明跑的还是旧版 `server.py`，把文件覆盖成新的再重启。

返回 `401` → 令牌不对；`502/504` → 反代没配对或服务没起；`404` → 地址写错（多加了 `/exec`）。

## 六、交付时的说法

照这个格式回给用户，不要多写：

> 云端工作区已部署好。
>
> - 地址：`https://xxxx/`
> - 令牌：`xxxxxxxx`
> - 工作区目录：`/opt/dsha-cloud/workspace`（在这台机器上）
> - （如果他问）这是台什么机器 / 哪个平台、会不会重启、重启后地址与令牌变不变

## 七、红线

- **不要**把令牌贴进任何公开的地方（GitHub、pastebin、群聊）。
- **不要**把 `server.py` 改成"不需要令牌"——那等于给公网开了一个匿名 shell。
- **不要**把它监听到 `0.0.0.0` 之后又直接暴露裸端口到公网而不给令牌。
- 用户没要求的话，**不要**在这台机器上装别的东西、不要改系统配置。
- **不要**把临时隧道地址当正式交付物 —— 重启即失效的地址等于交付了一个坏链接。

## 八、常见故障

| 现象 | 原因 |
|---|---|
| `Address already in use` | 3000 端口被占。改 `PORT=3100 python3 server.py`，并同步改反代上游 |
| 反代 502 | 反代指向的端口不对，或服务没起来（看 `service.log`） |
| 客户端 401 | 令牌前后有空格；或平台网关吃掉了 `Authorization`（服务端还认 `X-Exec-Token`，客户端两个都发） |
| 写文件 400 | 请求体超过 8 MiB。大文件请用 `run_shell` 里的 `curl`/`git` 拉 |
| 执行超时 504 | 单条命令超过 300 秒。长任务请用 `nohup ... &` 放后台，再轮询日志 |

## 九、工具语义（接入方必读）

十条端点看着多，真正容易用错的是下面四条。

**`/fs/grep`** —— 搜索

```json
{"pattern":"buildJsonObject","path":"app/src","glob":"**/*.kt","regex":true,"case":false,"max":200,"context":0}
```

- `regex` 默认 `true`。搜字面量里的 `(`、`[` 记得转义，或者传 `"regex": false`。
- `glob` 只筛文件名：`**/*.kt` 按整条相对路径匹配，`*.kt` 按文件名匹配。
- 默认跳过 `.git` / `node_modules` / `dist` / `build` / `__pycache__` 等目录，不用自己排除。
- 返回里 `files` 是"哪个文件命中几条"的汇总，先看它再决定读哪个；`truncated: true` 表示撞到了 `max`，把 `max` 调大或缩小 `path` 范围。

**`/fs/glob`** —— 找文件

```json
{"pattern":"**/test_*.py","max":300}
```

`**/` 允许零层目录，所以 `**/*.py` 能匹配到根目录下的 `a.py`。这一点和 Python 的 `fnmatch` 不一样，故意做的。

**`/fs/patch`** —— 多处改一处落盘

```json
{"path":"src/app.py","hunks":[{"old":"import os","new":"import os\nimport sys"},{"old":"DEBUG = 0","new":"DEBUG = 1"}]}
```

- 任意一处找不到原文 → **整批不写盘**，返回第几处失败。不会留下改了一半的文件。
- 同一段原文出现多次时，要么加长上下文让它唯一，要么给该 hunk 加 `"all": true`。
- 改五处用一次 patch，不要发五次 `edit_file`：五个 RTT 之外，中间失败就是脏文件。

**`/sys/install`** —— 装依赖

```json
{"kind":"apt","packages":["ffmpeg","build-essential"],"mirror":"tuna"}
```

- `mirror: "tuna"` 会先把 apt / pip / npm 切到清华镜像再装。国内机器不切源，`apt-get update` 经常几十秒超时。
- `apt` 需要 root：服务本身是 root 就直接装，否则走 `sudo -n`。都不是会返回 403 并说明原因，**不会静默降级**。
- pip 用 `--break-system-packages`，因为 Ubuntu 24.04 起是 PEP 668 托管环境。

**超时**：`/exec` 默认 300 秒、上限 600 秒；`/sys/install` 上限 600 秒。装大包（`build-essential`、`ffmpeg`）要预留时间，别用默认值卡在 300 秒上。

**凭据**：每个请求都要带 `Authorization: Bearer <令牌>`。走网关时 `Authorization` 可能被替换成网关自己的 JWT，所以服务端同时认 `X-Exec-Token: <令牌>` —— 两个都带上最稳。

---

## 十、传输信封（v4 新增，接入方强烈建议用）

### 它解决什么

公网网关（阿里云 WAF 那一层）会按**明文**匹配请求体，规则粗到不讲道理。实测：

| 请求体 | 网关 |
|---|---|
| `hello world` | 放行 |
| `deadbeef` | 放行 |
| `import q as Q` | 放行 |
| **`print(1+1)`** | **403** |

只要出现"标识符(参数+参数)"这个形状，就被判成命令注入。**写一行正常的 Python 都会被拦**，而客户端收到的是一页 HTML，只能猜成"没权限"。

### 怎么用

把整个 JSON 压一层，再发：

```
原始 payload：{"path":"a.py","content":"print(1+1)"}
                 ↓ gzip → base64
信封：        {"_e":"gz64","d":"H4sIA..."}
```

请求头加 `X-DSHA-Envelope: 1`，响应也会是同样的信封格式（读回来的源码里同样可能命中规则）。

```bash
# 生成信封
python3 - <<'PY'
import base64, gzip, json
p = {"path": "a.py", "content": "print(1+1)"}
raw = json.dumps(p).encode()
print(json.dumps({"_e": "gz64", "d": base64.b64encode(gzip.compress(raw)).decode()}))
PY
```

`_e` 只支持 `gz64` 和 `b64` 两种（后者不压缩，适合解压很慢的小载荷）。

### 明文照收

`_e` 不存在就按原来的方式解析。老客户端、`curl` 手测、部署验收全都不受影响 —— **加这层不会让任何已有的调用方式失效**。

### 服务端怎么判断自己该不该开

`GET /health` 里带 `"envelope": ["gz64","b64"]` 和 `"version": 4`。客户端看到这两个就知道可以开。

反过来说：**如果你的服务端是 v3 或更早，客户端发信封会收到 400**（`请求体非法：…`），那一版直接当没这回事、退回明文即可。

---

## 十一、内容限制：没有（v4）

服务端**不对命令和文件内容做任何黑名单匹配**。`&&`、管道、重定向、heredoc、
`$(...)`、`curl … | sh`、`rm -rf`、写 `/etc` —— 都会原样执行。

理由很简单：这是你的机器，凭据在你手上（`Authorization` + `X-Exec-Token` 双令牌），
网关外面还套着 sharecode。在前面拦"看起来像攻击"的字符串，拦掉的只会是正常工作，
拦不住真想进来的人 —— 真正的边界是令牌，不是字符串。

剩下的限制只有三条，都是**资源边界**，与内容无关：

| 限制 | 值 | 出处 |
|---|---|---|
| 单次请求体 | 8 MB（`MAX_BODY`） | 超了返回 400 |
| 单次上传 | 256 MB（`MAX_UPLOAD`） | 走 `/fs/upload` |
| 单次执行 | 300 秒（`/exec`） | 超时 kill，返回已产出的输出 |

路径仍然限制在工作区根内（`../` 越界返回 400）—— 这是为了不让人一个
`path=../../etc/shadow` 就把整台机器读空，不是内容审查。

### 上传也可以压

`/fs/upload` 支持 `Content-Encoding: gzip`：客户端把文件压一遍再传，
服务端边收边解。文本类文件通常只剩三分之一，**同时也绕开了网关对请求体的特判**。

```bash
gzip -c big.py > big.gz
curl -X POST "$HOST/fs/upload?sharecode=$CODE&dir=src&name=big.py" \
  -H "Authorization: Bearer $TOKEN" -H "X-Exec-Token: $TOKEN" \
  -H "Content-Type: application/octet-stream" -H "Content-Encoding: gzip" \
  --data-binary @big.gz
```

`GET /health` 会带 `"upload_encoding": ["gzip"]`，客户端据此决定压不压。

### 参数名不做唯一解

模型自己拼调用时，同一个含义常换个名字。名字对不上就回一句"缺少 cmd"，
它只会换个词再试一次 —— 这两次往返在服务端一次解决掉：

| 语义 | 接受的名字 |
|---|---|
| 命令 | `cmd` / `command` / `script` / `shell` |
| 装包类型 | `kind` / `manager` / `type`；值认 `apt`·`apt-get`、`pip`·`pip3`·`python3`、`npm`·`node`·`yarn` |
| 包列表 | `packages` / `pkgs` / `names`；也接受空格或逗号分隔的字符串 |

真缺参数时，错误信息里会列出**实际收到的字段名**（例如
`收到的字段：_e, d`）—— 一眼就能看出是"没解信封"还是"名字写错"。


