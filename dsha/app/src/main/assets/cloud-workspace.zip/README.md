# DSHA 云端工作区 · v2

给 DSHA 客户端用的工作区服务。把一块目录放到公网机器上，手机就能像操作本地目录一样
读写它、在里面跑命令、跑 Python。

v2 的重点不是加功能，而是**把"裸 shell"换成结构化工具**：搜索走 `/fs/grep`、
找文件走 `/fs/glob`、改多处走 `/fs/patch`、装依赖走 `/sys/install`。
AI 不需要再拼 `grep -rn --include=...` 这种端口之间行为不一的命令。

`GET /tools` 直接返回 OpenAI / Anthropic / MCP 通用的工具清单（含 JSON Schema），
任何客户端接进来就能用，不必读文档。

## 为什么会有这个东西

DSHA 的工作区有三种绑定方式：

| 方式 | 需要什么 | 适合谁 |
|---|---|---|
| 内置目录 | 什么都不用 | 随手记点东西 |
| 本机目录 | 「所有文件访问」权限 | 手机上有现成项目 |
| **云端环境** | 一台能跑 python3 的机器 | **不想装 Ubuntu、不想占手机存储** |

这一包就是第三种。它很小（几十 KB）、没有依赖，跑起来就有一个 HTTP 接口。

## 怎么用

**你不需要会部署。** 把这个 zip 直接发给任意一个能操作服务器的 AI，附一句话：

> 把这个压缩包解开，按里面的 DEPLOY.md 部署到公网，然后把访问地址和令牌给我。

它会回你两样东西：

```
地址：https://xxxx/
令牌：xxxxxxxx
```

回到 DSHA：设置 → 工作区 → 云端环境 → 添加，把地址和令牌填进去，「测试连接」通了就能用。
每个对话单独绑一个环境，不同话题之间不会串。

## 自己部署（如果你会）

```bash
mkdir -p /opt/dsha-cloud && cd /opt/dsha-cloud
# 拷入 server.py、run.sh
chmod +x run.sh
DSHA_ROOT=/opt/dsha-cloud/workspace nohup ./run.sh > /dev/null 2>&1 &
tail -f service.log
```

日志里会打印地址和令牌。

## 包里有什么

```
server.py            服务本体（单文件，标准库）
run.sh               进程守护（崩了 1 秒内拉起）
DEPLOY.md            给 AI 的部署说明
README.md            这份文件
client-example.sh    命令行调用的例子
token.txt            首次启动自动生成（不在包里，在运行目录）
```

## 安全

- 令牌等于**那台机器上的 shell 权限**。别贴到公开的地方。
- 服务本身不做沙箱：`/exec` 以运行它的用户身份执行命令。请用普通用户跑，别用 root。
- 只开一个端口。不要把它挂到公网却不给令牌 —— 那是一个匿名 shell。

## 配置项

| 环境变量 | 默认 | 说明 |
|---|---|---|
| `PORT` | `3000` | 监听端口 |
| `DSHA_ROOT` | `~/dsha-workspace` | 工作区根目录，不存在会自动创建 |
| `DSHA_TOKEN` | 自动生成 | 固定令牌（推荐在平台环境变量里设死，避免重启后变） |
