#!/bin/sh
# 用命令行验证一个已经部署好的工作区。
#
#   ./client-example.sh https://xxx/ <令牌>
#
# 这四条覆盖了 AI 最常用的路径：探活、看环境、搜内容、读文件。
# 任何一条失败，先看返回的 JSON 里的 error，再对照 DEPLOY.md 第八节。

set -u
BASE=${1:?用法: ./client-example.sh <地址> <令牌>}
TOKEN=${2:?缺令牌}
BASE=${BASE%/}

hdr_auth="Authorization: Bearer $TOKEN"
hdr_json="Content-Type: application/json"

echo "== 1. 探活 =="
curl -sS "$BASE/" ; echo

echo "== 2. 环境 =="
curl -sS -X POST "$BASE/sys/info" -H "$hdr_auth" -H "$hdr_json" -d '{}' \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d["distro"], "| root:", d["root"], "| sudo:", d["sudo"]); print("能力:", " ".join(d.get("capabilities", [])))'

echo "== 3. 工具清单 =="
curl -sS "$BASE/tools" -H "$hdr_auth" \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); print("\n".join("- " + t["name"] for t in d["tools"]))'

echo "== 4. 写一个文件再搜出来 =="
curl -sS -X POST "$BASE/fs/write" -H "$hdr_auth" -H "$hdr_json" \
  -d '{"path":"probe.txt","content":"line one\nline two needle\n"}' > /dev/null
curl -sS -X POST "$BASE/fs/grep" -H "$hdr_auth" -H "$hdr_json" \
  -d '{"pattern":"needle"}' \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); print("命中", len(d["matches"]), "条，扫描", d["files_scanned"], "个文件")'

echo "== 5. 列目录 =="
curl -sS -X POST "$BASE/fs/list" -H "$hdr_auth" -H "$hdr_json" -d '{}' \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); print(" ".join(e["name"] for e in d["entries"]) or "(空)")'
