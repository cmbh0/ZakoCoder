#!/bin/sh
# 进程守护：server.py 退出后 1 秒内自动拉起。
#
# 为什么需要它：很多容器平台 / SSH 会话只保证"你启动的那个进程"活着，
# 而服务可能因为一次未捕获的异常退出。有一个 while 循环兜着，用户那边
# 表现为"偶尔重连一下"，而不是"链接彻底死了还得回去找他重新部署"。
#
# flock 保证同一台机器上只有一个守护实例：重复执行本脚本不会抢端口。
set -eu

DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$DIR" || exit 1

LOCK="${TMPDIR:-/tmp}/dsha-cloud.supervisor.lock"
exec 9>"$LOCK"
if ! flock -n 9; then
    echo "已有实例在运行，退出。"
    exit 0
fi

mkdir -p "${DSHA_ROOT:-$HOME/dsha-workspace}"

while :; do
    python3 server.py >> service.log 2>&1 || true
    echo "[$(date -Iseconds 2>/dev/null || date)] server exited, restart in 1s" >> service.log
    sleep 1
done
