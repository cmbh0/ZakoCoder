#!/usr/bin/env python3
"""DSHA 云端工作区服务 · v2。

一个文件、只用标准库、不需要任何第三方包。

这不是"给个 shell 让 AI 自己 cat"，而是一套**结构化工具**：
搜索走 /fs/grep，找文件走 /fs/glob，改多处走 /fs/patch。每一条都比
让模型拼 `grep -rn` 更可靠 —— 不用记 GNU 与 busybox 的参数差异，
不用怕输出被截断，也拿得到结构化的行号。

GET  /tools               工具清单（OpenAI / Anthropic / MCP 都能直接吃）
                           ——把它丢给任何客户端，对方就知道这里有什么、怎么调。

POST /exec                {"cmd","cwd","timeout","sudo"}
POST /sys/info            {"root","sudo","distro","tools","capabilities"}
POST /sys/install         {"kind":"apt|pip|npm","packages":[...],"mirror":"tuna"}
POST /fs/list             {"path"}
POST /fs/read             {"path","offset","limit"}
POST /fs/write            {"path","content","append","encoding":"utf-8|base64"}
POST /fs/edit             {"path","old","new"}
POST /fs/patch            {"path","hunks":[{"old","new","all":false}]}
POST /fs/grep             {"pattern","path","glob","regex","case","max","context"}
POST /fs/glob             {"pattern","path","max"}
POST /fs/tree             {"path","depth","max"}
POST /fs/mkdir            {"path"}
POST /fs/stat             {"path"}
POST /fs/remove           {"path","recursive"}
POST /fs/move             {"from","to","overwrite"}
GET  /                    探活，不需要凭据

所有路径都相对于 ROOT，越界一律拒绝（`..`、符号链接指向外面都算）。

启动：
    python3 server.py
    PORT=8080 DSHA_ROOT=/srv/proj DSHA_TOKEN=xxx python3 server.py

凭据优先级：环境变量 DSHA_TOKEN > 同目录 token.txt > 自动生成并写回 token.txt。
"""

import base64
import gzip
import hmac
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import time
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlsplit

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get("PORT", "3000"))
ROOT = os.path.realpath(os.path.expanduser(os.environ.get("DSHA_ROOT", "~/dsha-workspace")))
MAX_BODY = 8 << 20          # 8 MiB：写文件要能塞下一整篇源码
MAX_UPLOAD = 256 << 20      # 256 MiB：手机传 APK / 视频 / 数据集，走原始字节流
EXEC_TIMEOUT_DEFAULT = 300
EXEC_TIMEOUT_MAX = 600
READ_MAX_DEFAULT = 400_000
GREP_MAX_FILE = 2 << 20     # 单文件 2 MiB：再大基本是数据不是代码
VERSION = 4

# 搜索时默认跳过的目录。这些目录里的命中对模型没有价值，却能把结果挤满。
DEFAULT_IGNORE = (
    ".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv",
    "dist", "build", "target", ".idea", ".gradle", ".mypy_cache", ".pytest_cache",
)

# 常用命令探测表。/sys/info 靠它回答"这台机器上有什么"。
PROBE_COMMANDS = [
    "git", "python3", "pip3", "node", "npm", "pnpm", "yarn", "curl", "wget",
    "apt-get", "docker", "ffmpeg", "gcc", "make", "systemctl", "unzip", "rg",
]

TUNA = "https://mirrors.tuna.tsinghua.edu.cn"


def load_token():
    """令牌只从环境变量或 token.txt 取。都没有就生成一个并落盘。"""
    env = os.environ.get("DSHA_TOKEN", "").strip()
    if env:
        return env
    path = os.path.join(HERE, "token.txt")
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as fh:
            value = fh.read().strip()
        if value:
            return value
    value = secrets.token_urlsafe(32)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(value + "\n")
    os.chmod(path, 0o600)
    return value


TOKEN = load_token()


# 同一个"装依赖"，模型有时说 pip，有时说 pip3 / python / pypi。
# 名字对不上就回一句"kind 只能是 apt / pip / npm"，模型只会换个词再试一次 ——
# 这两次往返本该在服务端一次解决。
INSTALL_ALIASES = {
    "apt": "apt", "apt-get": "apt", "aptget": "apt", "deb": "apt", "debian": "apt",
    "pip": "pip", "pip3": "pip", "python": "pip", "python3": "pip", "pypi": "pip", "py": "pip",
    "npm": "npm", "node": "npm", "nodejs": "npm", "yarn": "npm", "pnpm": "npm",
}


def pick_str(payload, *names):
    """按顺序取第一个非空字符串参数。

    客户端对同一个含义的叫法并不统一（`cmd` / `command` / `script`）——
    只要名字对不上就判"缺少参数"，模型会换一个名字重来，白白多两次往返。
    这里一次认全。
    """
    for name in names:
        value = payload.get(name)
        if isinstance(value, str) and value.strip():
            return value
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return str(value)
    return ""


def resolve(relative):
    """把客户端给的相对路径解析成真实路径，越界抛 ValueError。"""
    if relative is None:
        relative = "."
    clean = str(relative).strip().lstrip("/")
    if clean in ("", "."):
        return ROOT
    target = os.path.realpath(os.path.join(ROOT, clean))
    if target != ROOT and not target.startswith(ROOT + os.sep):
        raise ValueError("路径越界：%s" % relative)
    return target


def rel(path):
    return os.path.relpath(path, ROOT).replace(os.sep, "/")


def glob_to_regex(pattern):
    """把 glob 转成正则，支持 `**`。

    为什么不用 fnmatch：它把 `*` 和 `**` 当同一件事，`src/**/*.py` 匹配不到
    `src/a.py`（只有一层时 `**/` 该匹配空）。AI 写路径几乎总是带 `**/`，
    容忍不了这个差异。
    """
    out = []
    i = 0
    n = len(pattern)
    while i < n:
        ch = pattern[i]
        if ch == "*":
            if i + 1 < n and pattern[i + 1] == "*":
                # `**/` 允许零层目录；单独的 `**` 匹配任意字符
                if i + 2 < n and pattern[i + 2] == "/":
                    out.append("(?:.*/)?")
                    i += 3
                    continue
                out.append(".*")
                i += 2
                continue
            out.append("[^/]*")
            i += 1
            continue
        if ch == "?":
            out.append("[^/]")
            i += 1
            continue
        if ch == "[":
            j = i + 1
            if j < n and pattern[j] in "!^":
                j += 1
            if j < n and pattern[j] == "]":
                j += 1
            while j < n and pattern[j] != "]":
                j += 1
            if j >= n:
                out.append("\\[")
                i += 1
                continue
            body = pattern[i + 1:j]
            if body.startswith("!"):
                body = "^" + body[1:]
            out.append("[" + body.replace("\\", "\\\\") + "]")
            i = j + 1
            continue
        out.append(re.escape(ch))
        i += 1
    return re.compile("^" + "".join(out) + "$")


# ── diff ─────────────────────────────────────────────────────
#
# 剥公共前后缀，中间整段标为删 / 增。
#
# 为什么不用 LCS：文件可能几千行，O(n·m) 在服务器上也是白烧 CPU，而这里
# 只服务一个用途 —— 让手机那边展开工具卡时能看见"改了哪几行"。
# 改动几乎总是局部的，剥完前后缀剩下的往往只有几十行。
CONTEXT_LINES = 3
MAX_MIDDLE = 240


def compute_diff(before, after):
    if before == after:
        return []
    old = before.split("\n") if before else []
    new = after.split("\n") if after else []
    if not before:
        return [{"t": "+", "s": line} for line in new]

    prefix = 0
    limit = min(len(old), len(new))
    while prefix < limit and old[prefix] == new[prefix]:
        prefix += 1

    suffix = 0
    limit2 = min(len(old) - prefix, len(new) - prefix)
    while suffix < limit2 and old[len(old) - 1 - suffix] == new[len(new) - 1 - suffix]:
        suffix += 1

    out = []
    for i in range(max(0, prefix - CONTEXT_LINES), prefix):
        out.append({"t": " ", "s": old[i]})

    def emit(lines, mark):
        if len(lines) <= MAX_MIDDLE:
            out.extend({"t": mark, "s": line} for line in lines)
            return
        head = MAX_MIDDLE // 2
        tail = MAX_MIDDLE - head
        out.extend({"t": mark, "s": line} for line in lines[:head])
        out.append({"t": " ", "s": "… 省略 %d 行 …" % (len(lines) - MAX_MIDDLE)})
        out.extend({"t": mark, "s": line} for line in lines[-tail:])

    emit(old[prefix:len(old) - suffix], "-")
    emit(new[prefix:len(new) - suffix], "+")

    for i in range(min(suffix, CONTEXT_LINES)):
        out.append({"t": " ", "s": new[len(new) - suffix + i]})
    return out


def exec_identity():
    """当前进程以谁的身份跑。"""
    try:
        import pwd
        user = pwd.getpwuid(os.geteuid()).pw_name
    except Exception:  # noqa: BLE001 —— 容器里可能没有 passwd 项
        user = str(os.geteuid())
    return os.geteuid(), user


def sudo_ready():
    """能不能非交互提权。

    只在"服务本身不是 root"时才有意义：是 root 的话，命令天生就是 root，
    不需要也不应该再套一层 sudo。
    """
    if os.geteuid() == 0:
        return True, "root"
    try:
        proc = subprocess.run(
            ["sudo", "-n", "true"], capture_output=True, timeout=5,
        )
        if proc.returncode == 0:
            return True, "sudo"
        return False, "no-passwordless-sudo"
    except FileNotFoundError:
        return False, "no-sudo"
    except Exception:  # noqa: BLE001
        return False, "sudo-error"


def probe_tools():
    """常用命令在不在 PATH 里。模型问"能不能装/能不能跑"时，这个比猜有用。"""
    found = {}
    for name in PROBE_COMMANDS:
        path = shutil.which(name)
        if path:
            found[name] = path
    return found


# ── 工具清单 ─────────────────────────────────────────────────
#
# 这一段是给**别的客户端**用的：把它返回的 JSON 直接塞进 tools 字段，
# 任何 OpenAI / Anthropic / MCP 的客户端都能立刻用起来，不需要读文档。
# 名字用下划线形式（OpenAI 的限制），和手机端内置工具同名，
# 这样模型在本地与云端看到的是同一套词汇。

TOOLS = [
    {
        "name": "read_file",
        "description": "读取工作区里的一个文本文件。修改前先用它看清现状；读大文件时用 offset/limit 分段读。",
        "method": "POST",
        "path": "/fs/read",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "相对工作区的路径"},
                "offset": {"type": "integer", "description": "起始行，1 起"},
                "limit": {"type": "integer", "description": "最多读多少行，默认 400"},
            },
            "required": ["path"],
        },
        "map": {"path": "path", "offset": "offset", "limit": "limit"},
    },
    {
        "name": "write_file",
        "description": "把内容整体写入一个文件（覆盖）。新建文件或整篇替换时用；只改几行请用 edit_file 或 patch_file。",
        "method": "POST",
        "path": "/fs/write",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["path", "content"],
        },
        "map": {"path": "path", "content": "content"},
    },
    {
        "name": "upload_file",
        "description": "把任意文件（图片、APK、压缩包）以原始字节流上传到工作区。"
                       "参数走查询串，请求体就是文件本身，不做 base64 膨胀。",
        "method": "POST",
        "path": "/fs/upload?dir=<目录>&name=<文件名>",
        "input_schema": {
            "type": "object",
            "properties": {
                "dir": {"type": "string", "description": "目标目录，相对工作区根，默认 ."},
                "name": {"type": "string", "description": "文件名，只取最后一段"},
                "content": {"type": "string", "description": "原始字节（binary body）"},
            },
            "required": ["name", "content"],
        },
        "map": {"dir": "dir", "name": "name"},
    },
    {
        "name": "download_file",
        "description": "把工作区里的一个文件原样下载（原始字节流）。",
        "method": "GET",
        "path": "/fs/download?path=<文件>",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
        "map": {"path": "path"},
    },
    {
        "name": "edit_file",
        "description": "把文件里的一段原文替换成新文本。old 必须与文件内容逐字符一致（含缩进），且唯一。",
        "method": "POST",
        "path": "/fs/edit",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "old": {"type": "string", "description": "要被替换的原文，唯一"},
                "new": {"type": "string"},
            },
            "required": ["path", "old", "new"],
        },
        "map": {"path": "path", "old": "old", "new": "new"},
    },
    {
        "name": "patch_file",
        "description": "一次性把多处改动写进同一个文件。hunks 里每一项是一处 old/new 替换，按顺序应用；"
                       "任意一处找不到原文就整批不落盘（不会留下改了一半的文件）。",
        "method": "POST",
        "path": "/fs/patch",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "hunks": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "old": {"type": "string"},
                            "new": {"type": "string"},
                            "all": {"type": "boolean", "description": "true = 替换所有出现处"},
                        },
                        "required": ["old", "new"],
                    },
                },
            },
            "required": ["path", "hunks"],
        },
        "map": {"path": "path", "hunks": "hunks"},
    },
    {
        "name": "search_content",
        "description": "在文件内容里搜索（相当于 grep -rn）。按路径过滤用 glob，例如 src/**/*.py。"
                       "返回匹配的文件名、行号与整行文本。不确定某个符号/字符串在哪时用它，比逐个 read_file 快得多。",
        "method": "POST",
        "path": "/fs/grep",
        "input_schema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "要搜的文本或正则"},
                "path": {"type": "string", "description": "搜索起点，默认工作区根"},
                "glob": {"type": "string", "description": "只搜匹配的文件，如 **/*.kt、*.md"},
                "regex": {"type": "boolean", "description": "pattern 是否按正则解释，默认 true"},
                "case": {"type": "boolean", "description": "是否区分大小写，默认 false"},
                "max": {"type": "integer", "description": "最多返回多少条匹配，默认 200"},
                "context": {"type": "integer", "description": "每条匹配前后各带几行，默认 0"},
            },
            "required": ["pattern"],
        },
        "map": {"pattern": "pattern", "path": "path", "glob": "glob", "regex": "regex",
                "case": "case", "max": "max", "context": "context"},
    },
    {
        "name": "find_files",
        "description": "按文件名找文件（相当于 find / glob）。pattern 支持 **，例如 **/*.py、src/**/test_*.js。",
        "method": "POST",
        "path": "/fs/glob",
        "input_schema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string"},
                "path": {"type": "string", "description": "搜索起点，默认工作区根"},
                "max": {"type": "integer", "description": "最多返回多少个，默认 300"},
            },
            "required": ["pattern"],
        },
        "map": {"pattern": "pattern", "path": "path", "max": "max"},
    },
    {
        "name": "list_dir",
        "description": "列目录。先看结构再动手，比猜路径可靠。",
        "method": "POST",
        "path": "/fs/list",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string", "description": "留空表示根目录"}},
            "required": [],
        },
        "map": {"path": "path"},
    },
    {
        "name": "run_shell",
        "description": "执行一条 shell 命令。每次调用是独立 shell，不保留 cd 和环境变量。"
                       "需要系统级权限时把 sudo 设为 true。",
        "method": "POST",
        "path": "/exec",
        "input_schema": {
            "type": "object",
            "properties": {
                "cmd": {"type": "string"},
                "cwd": {"type": "string"},
                "timeout": {"type": "integer", "description": "秒，默认 300，上限 600"},
                "sudo": {"type": "boolean"},
            },
            "required": ["cmd"],
        },
        "map": {"cmd": "cmd", "cwd": "cwd", "timeout": "timeout", "sudo": "sudo"},
    },
    {
        "name": "env_info",
        "description": "查看环境：发行版、内核、当前用户、能否提权、常用命令是否已安装。开始一个需要系统权限的任务前先调一次。",
        "method": "POST",
        "path": "/sys/info",
        "input_schema": {"type": "object", "properties": {}, "required": []},
        "map": {},
    },
    {
        "name": "install_packages",
        "description": "安装依赖。kind=apt 装系统包、pip 装 Python 包、npm 装 Node 包；"
                       "mirror 为 tuna 时先切到清华源（国内服务器必选，否则动辄超时）。",
        "method": "POST",
        "path": "/sys/install",
        "input_schema": {
            "type": "object",
            "properties": {
                "kind": {"type": "string", "enum": ["apt", "pip", "npm"]},
                "packages": {"type": "array", "items": {"type": "string"}},
                "mirror": {"type": "string", "enum": ["tuna", "none"]},
            },
            "required": ["kind", "packages"],
        },
        "map": {"kind": "kind", "packages": "packages", "mirror": "mirror"},
    },
]


class _LimitedReader:
    """
    只允许读 `length` 字节的读包装。

    `self.rfile` 是 keep-alive 连接上的共享流，直接交给 `gzip.GzipFile`
    会读到下一个请求的字节里去。这里把它切成一段有明确边界的流。
    """

    def __init__(self, stream, length):
        self._stream = stream
        self._left = length

    def read(self, n=-1):
        if self._left <= 0:
            return b""
        if n is None or n < 0:
            n = self._left
        chunk = self._stream.read(min(n, self._left))
        self._left -= len(chunk)
        return chunk


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "dsha-cloud/2"

    # ── 基础设施 ──────────────────────────────────────────────

    def _send(self, status, payload):
        body = json.dumps(self._wrap(payload), ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _authorized(self):
        # 直连：Authorization: Bearer <TOKEN>
        if hmac.compare_digest(self.headers.get("Authorization", ""), "Bearer " + TOKEN):
            return True
        # 经反向代理 / 公网网关：Authorization 可能被网关换成它自己的 JWT，
        # 客户端的原值到不了这里。用可透传的自定义头承载同一凭据。
        return hmac.compare_digest(self.headers.get("X-Exec-Token", ""), TOKEN)

    def _read_json(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ValueError("Content-Length 非法")
        if not (0 < length <= MAX_BODY):
            raise ValueError("请求体长度非法（0 < len <= %d）" % MAX_BODY)
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8"))

    # 信封解压后的上限。8 MiB 的请求体理论上能炸出几 GB，这里卡死。
    ENVELOPE_LIMIT = 32 << 20

    def _unwrap(self, payload):
        """
        解开传输信封。

        ### 为什么要有这层东西

        公网网关（阿里云 WAF）按**明文**匹配请求体，规则粗到令人发指 ——
        实测连 `print(1+1)` 都会 403，因为"标识符(参数+参数)"这个形状被当成
        命令注入。AI 写一行再正常不过的 Python 都打不回来，而它收到的是一页
        HTML，只能猜成"没权限"，然后越猜越离谱。

        **内容本身没有对错，是这个匹配层不该管这么多。** 鉴权已经在前面做完了
        （sharecode + Bearer token），这里只负责把结构化的请求还原出来。
        所以客户端把整个 JSON 压一层：

            {"_e": "gz64", "d": "<base64(gzip(json))>"}

        网关看到的是一串随机字符，什么规则都不命中；到这儿还原成原样的 dict。

        ### 明文照收

        老客户端、`curl` 手测、部署自检全走明文，`_e` 不存在就原样返回。
        加这层**不会让任何旧的调用方式失效**。
        """
        if not isinstance(payload, dict):
            return payload
        kind = payload.get("_e")
        if kind is None:
            return payload

        blob = payload.get("d")
        if not isinstance(blob, str):
            raise ValueError("信封缺少 d 字段")
        try:
            packed = base64.b64decode(blob.encode("ascii"), validate=True)
        except Exception:
            raise ValueError("信封的 base64 解不开")

        if kind == "gz64":
            try:
                raw = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(packed, self.ENVELOPE_LIMIT)
            except zlib.error as exc:
                raise ValueError("信封的 gzip 解不开：%s" % exc)
        elif kind == "b64":
            raw = packed
        else:
            raise ValueError("不认识的信封类型：%s" % kind)

        if len(raw) >= self.ENVELOPE_LIMIT:
            raise ValueError("信封解压后超过 %d 字节" % self.ENVELOPE_LIMIT)

        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise ValueError("信封里的 JSON 非法：%s" % exc)

    def _wrap(self, payload):
        """
        把响应也装进信封 —— 只在客户端要求时。

        WAF 一般只查请求，但既然它连 `print(1+1)` 都要拦，读回来的源码里
        同样可能命中规则（`/fs/read` 读一个 .py 文件就是一大堆括号）。
        客户端带 `X-DSHA-Envelope: 1` 时，响应体统一封装。
        """
        if self.headers.get("X-DSHA-Envelope") != "1":
            return payload
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        packed = base64.b64encode(gzip.compress(raw, 5)).decode("ascii")
        return {"_e": "gz64", "d": packed}

    def log_message(self, fmt, *args):
        # 默认会把每个请求打到 stderr。自己收紧一点，并且绝不打印请求体（里面可能是文件内容）。
        sys.stderr.write("[%s] %s %s\n" % (time.strftime("%H:%M:%S"), self.address_string(), fmt % args))

    # ── 路由 ─────────────────────────────────────────────────

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path in ("/", "/health"):
            return self._send(200, {
                "ok": True,
                "service": "dsha-cloud",
                "version": VERSION,
                "root": ROOT,
                "time": int(time.time()),
                # 客户端据此决定要不要把请求装进信封（见 _unwrap）
                "envelope": ["gz64", "b64"],
                # 上传可选的压缩方式；不认这个字段的客户端发明文也照样能收
                "upload_encoding": ["gzip"],
                "limits": {"body": MAX_BODY, "upload": MAX_UPLOAD, "exec_seconds": 300},
            })
        if path == "/tools":
            if not self._authorized():
                return self._send(401, {"error": "unauthorized：令牌不对（Authorization 或 X-Exec-Token）"})
            return self._send(200, {
                "service": "dsha-cloud",
                "version": VERSION,
                "transport": "http-json",
                "auth": "Authorization: Bearer <token> 或 X-Exec-Token: <token>",
                "root": ROOT,
                "upload": {"max": MAX_UPLOAD, "endpoint": "/fs/upload?dir=<目录>&name=<文件名>",
                           "content_type": "application/octet-stream",
                           "encoding": ["gzip"]},
                "tools": TOOLS,
            })
        if path == "/fs/download":
            if not self._authorized():
                return self._send(401, {"error": "unauthorized：令牌不对（Authorization 或 X-Exec-Token）"})
            return self._fs_download()
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        if not self._authorized():
            return self._send(401, {"error": "unauthorized：令牌不对（Authorization 或 X-Exec-Token）"})

        # 上传走**原始字节流**，在读 JSON 之前分流。
        # 早先所有 POST 都先 `_read_json`，那对二进制文件是致命的：
        # `json.loads` 会在半个文件处炸掉，而请求体已经读完，没法补救。
        if path == "/fs/upload":
            try:
                return self._fs_upload()
            except ValueError as exc:
                return self._send(400, {"error": str(exc)})
            except Exception as exc:  # noqa: BLE001
                return self._send(500, {"error": "%s: %s" % (type(exc).__name__, exc)})

        try:
            payload = self._unwrap(self._read_json())
        except (ValueError, UnicodeDecodeError) as exc:
            return self._send(400, {"error": "请求体非法：%s" % exc})

        try:
            if path == "/sys/info":
                return self._sys_info(payload)
            if path == "/sys/install":
                return self._sys_install(payload)
            if path == "/exec":
                return self._exec(payload)
            if path == "/fs/list":
                return self._fs_list(payload)
            if path == "/fs/read":
                return self._fs_read(payload)
            if path == "/fs/write":
                return self._fs_write(payload)
            if path == "/fs/edit":
                return self._fs_edit(payload)
            if path == "/fs/patch":
                return self._fs_patch(payload)
            if path == "/fs/grep":
                return self._fs_grep(payload)
            if path == "/fs/glob":
                return self._fs_glob(payload)
            if path == "/fs/tree":
                return self._fs_tree(payload)
            if path == "/fs/mkdir":
                return self._fs_mkdir(payload)
            if path == "/fs/stat":
                return self._fs_stat(payload)
            if path == "/fs/remove":
                return self._fs_remove(payload)
            if path == "/fs/move":
                return self._fs_move(payload)
        except ValueError as exc:
            return self._send(400, {"error": str(exc)})
        except Exception as exc:  # noqa: BLE001 —— 兜底，不要让一次异常把连接吊死
            return self._send(500, {"error": "%s: %s" % (type(exc).__name__, exc)})

        return self._send(404, {"error": "not found"})

    # ── /exec ────────────────────────────────────────────────

    def _exec(self, payload):
        cmd = pick_str(payload, "cmd", "command", "script", "shell", "commandLine", "command_line")
        if not cmd:
            raise ValueError(
                "缺少命令：需要 cmd（也接受 command / script）。收到的字段：%s"
                % (", ".join(sorted(payload.keys())) or "（空）")
            )

        timeout = payload.get("timeout", EXEC_TIMEOUT_DEFAULT)
        try:
            timeout = max(1, min(int(timeout), EXEC_TIMEOUT_MAX))
        except (TypeError, ValueError):
            timeout = EXEC_TIMEOUT_DEFAULT

        cwd = ROOT
        if payload.get("cwd"):
            cwd = resolve(payload["cwd"])
            if not os.path.isdir(cwd):
                raise ValueError("cwd 不是目录：%s" % payload["cwd"])

        elevated = False
        if bool(payload.get("sudo")):
            if os.geteuid() == 0:
                # 已经是 root：命令天生就有权限，不必也不该再套 sudo
                elevated = True
            else:
                ready, why = sudo_ready()
                if not ready:
                    # 明确报错而不是"看起来跑了其实没权限" —— 后者会浪费模型好几轮
                    return self._send(403, {
                        "error": "云端进程没有免密 sudo 权限（%s）。"
                                 "部署时用 root 启动服务，或为运行用户配置 NOPASSWD。" % why,
                        "sudo": False,
                    })
                cmd = "sudo -n " + cmd
                elevated = True

        try:
            proc = subprocess.run(
                cmd,
                shell=True,          # 支持管道、重定向、&& —— 这是"终端"该有的语义
                cwd=cwd,
                capture_output=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            return self._send(504, {"error": "timeout", "timeout": timeout})

        euid, user = exec_identity()
        return self._send(200, {
            "stdout": proc.stdout,
            "stderr": proc.stderr,
            "exit_code": proc.returncode,
            "cwd": rel(cwd),
            "root": euid == 0,
            "elevated": elevated,
            "user": user,
        })

    # ── /sys/info ────────────────────────────────────────────

    def _sys_info(self, payload):
        euid, user = exec_identity()
        sudo_ok, sudo_why = sudo_ready()
        distro = ""
        try:
            with open("/etc/os-release", "r", encoding="utf-8") as fh:
                for line in fh:
                    if line.startswith("PRETTY_NAME="):
                        distro = line.split("=", 1)[1].strip().strip('"')
                        break
        except OSError:
            pass
        return self._send(200, {
            "root": euid == 0,
            "euid": euid,
            "user": user,
            "sudo": sudo_ok,
            "sudo_reason": sudo_why,
            "distro": distro or "linux",
            "kernel": os.uname().release,
            "python": sys.version.split()[0],
            "root_dir": ROOT,
            "tools": probe_tools(),
            # 客户端据此判断"要不要给模型挂 grep/glob 这些工具"，
            # 旧版服务没有这些端点，挂了也是白挂。
            "capabilities": ["fs.grep", "fs.glob", "fs.patch", "fs.tree",
                             "sys.install", "tools.manifest"],
        })

    # ── /sys/install ─────────────────────────────────────────
    #
    # 单独一条端点，而不是让模型拼 `apt-get install`：
    # 国内服务器直连 archive.ubuntu.com 经常几十秒超时，而模型并不知道要换源。
    # 这里把"换源 + 安装 + 清理"合成一步，失败也能给出可读的原因。

    def _sys_install(self, payload):
        raw_kind = payload.get("kind") or payload.get("manager") or payload.get("type") or ""
        kind = str(raw_kind).strip().lower()
        kind = INSTALL_ALIASES.get(kind, kind)
        if kind not in ("apt", "pip", "npm"):
            raise ValueError(
                "kind 只能是 apt / pip / npm（收到 %r）" % (raw_kind,)
            )
        packages = payload.get("packages") or payload.get("pkgs") or payload.get("names") or []
        if isinstance(packages, str):
            packages = [p for p in re.split(r"[\s,]+", packages) if p]
        if not isinstance(packages, list) or not packages:
            raise ValueError("packages 必须是非空数组（也接受空格分隔的字符串）")
        packages = [str(p).strip() for p in packages if str(p).strip()]
        for name in packages:
            # 包名要拼进命令行，这里挡掉 shell 元字符 —— 否则等于给了任意命令执行
            if not re.fullmatch(r"[A-Za-z0-9._@/:+=<>~-]+", name):
                raise ValueError("包名含非法字符：%s" % name)
        mirror = payload.get("mirror", "tuna")
        timeout = min(int(payload.get("timeout", EXEC_TIMEOUT_MAX) or EXEC_TIMEOUT_MAX), EXEC_TIMEOUT_MAX)

        euid = os.geteuid()
        sudo = "" if euid == 0 else "sudo -n "
        log = []

        def run(cmd, limit=90):
            try:
                proc = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                                      errors="replace", timeout=limit)
            except subprocess.TimeoutExpired:
                log.append("$ %s\n（超时 %ds）" % (cmd, limit))
                return 124
            tail = (proc.stdout or "") + (proc.stderr or "")
            log.append("$ %s\n%s" % (cmd, tail.strip()[-4000:]))
            return proc.returncode

        if mirror == "tuna":
            if kind == "apt":
                if _switch_apt_tuna():
                    log.append("已将 apt 源切到清华镜像")
            elif kind == "pip":
                run("python3 -m pip config set global.index-url %s/pypi/web/simple" % TUNA, 30)
                run("python3 -m pip config set global.trusted-host mirrors.tuna.tsinghua.edu.cn", 30)
            elif kind == "npm":
                run("npm config set registry https://registry.npmmirror.com", 30)

        if kind == "apt":
            cmd = sudo + "env DEBIAN_FRONTEND=noninteractive apt-get install -y " + " ".join(packages)
        elif kind == "pip":
            cmd = "python3 -m pip install --break-system-packages " + " ".join(packages)
        else:
            cmd = "npm install -g " + " ".join(packages)

        code = run(cmd, timeout)
        return self._send(200 if code == 0 else 500, {
            "ok": code == 0,
            "kind": kind,
            "packages": packages,
            "exit_code": code,
            "log": "\n\n".join(log)[-12000:],
        })

    # ── 文件系统 ─────────────────────────────────────────────

    def _fs_list(self, payload):
        """列一层目录：名字、是否目录、大小、mtime；目录在前。"""
        target = resolve(payload.get("path"))
        if not os.path.isdir(target):
            raise ValueError("不是目录：%s" % payload.get("path"))
        entries = []
        with os.scandir(target) as it:
            for entry in it:
                try:
                    stat = entry.stat(follow_symlinks=False)
                    entries.append({
                        "name": entry.name,
                        "dir": entry.is_dir(follow_symlinks=False),
                        "size": stat.st_size,
                        "mtime": int(stat.st_mtime),
                    })
                except OSError:
                    continue
        entries.sort(key=lambda item: (not item["dir"], item["name"].lower()))
        return self._send(200, {"path": rel(target), "entries": entries})

    def _fs_read(self, payload):
        target = resolve(payload.get("path"))
        if not os.path.isfile(target):
            raise ValueError("不是文件：%s" % payload.get("path"))

        limit = payload.get("max", READ_MAX_DEFAULT)
        try:
            limit = max(1, int(limit))
        except (TypeError, ValueError):
            limit = READ_MAX_DEFAULT
        size = os.path.getsize(target)

        # 带了 offset/limit 就由服务端按行切：几千行的文件只回 400 行，
        # 手机上既省一次全量传输，也省一次本地切分。
        offset = payload.get("offset")
        if offset is not None:
            try:
                offset = max(1, int(offset))
                want = max(1, int(payload.get("limit", 400)))
            except (TypeError, ValueError):
                raise ValueError("offset / limit 必须是整数")
            with open(target, "r", encoding="utf-8", errors="replace") as fh:
                lines = fh.read().split("\n")
            total = len(lines)
            chunk = lines[offset - 1:offset - 1 + want]
            return self._send(200, {
                "path": rel(target),
                "size": size,
                "offset": offset,
                "limit": want,
                "start_line": offset,
                "end_line": offset + len(chunk) - 1 if chunk else offset - 1,
                "total_lines": total,
                "content": "\n".join(chunk),
            })

        with open(target, "rb") as fh:
            raw = fh.read(limit)
        # 没带 offset：整篇返回，顺带给出总行数，客户端按行号展示
        text = raw.decode("utf-8", errors="replace")
        return self._send(200, {
            "path": rel(target),
            "size": size,
            "truncated": size > len(raw),
            "encoding": "utf-8",
            "total_lines": text.count("\n") + 1,
            "content": text,
        })

    def _fs_write(self, payload):
        target = resolve(payload.get("path"))
        content = payload.get("content")
        if not isinstance(content, str):
            raise ValueError("content 必须是字符串")
        encoding = payload.get("encoding", "utf-8")
        data = base64.b64decode(content) if encoding == "base64" else content.encode("utf-8")

        parent = os.path.dirname(target)
        if parent:
            os.makedirs(parent, exist_ok=True)

        # 写之前留一份旧文本，只为了回一份 diff。放在同一个请求里 ——
        # 让客户端先读再写会多一次往返，云端 RTT 比本地 IO 贵得多。
        before = ""
        append = bool(payload.get("append"))
        if not append and os.path.isfile(target) and os.path.getsize(target) <= 4 * 1024 * 1024:
            try:
                with open(target, "r", encoding="utf-8", errors="replace") as fh:
                    before = fh.read()
            except OSError:
                before = ""

        mode = "ab" if append else "wb"
        with open(target, mode) as fh:
            fh.write(data)

        diff = []
        if not append and encoding != "base64":
            diff = compute_diff(before, content)
        return self._send(200, {"path": rel(target), "bytes": len(data), "diff": diff})

    def _fs_edit(self, payload):
        """读 → 换 → 写，一次往返带回 diff。

        客户端要是先 read 再 write，云端就是两次 RTT 加两次全文传输；
        改动判重（唯一性）也得在客户端做。放到服务端，这些全在一个请求里。
        """
        target = resolve(payload.get("path"))
        if not os.path.isfile(target):
            raise ValueError("不是文件：%s" % payload.get("path"))
        old = payload.get("old")
        new = payload.get("new", "")
        if not isinstance(old, str) or not old:
            raise ValueError("old 必须是非空字符串")
        if not isinstance(new, str):
            raise ValueError("new 必须是字符串")
        if os.path.getsize(target) > 4 * 1024 * 1024:
            raise ValueError("文件过大（超过 4 MB），请用 run_shell 处理")

        with open(target, "r", encoding="utf-8", errors="replace") as fh:
            text = fh.read()

        first = text.find(old)
        if first < 0:
            raise ValueError("文件里找不到这段原文（注意缩进与空行）")
        if text.find(old, first + 1) >= 0:
            raise ValueError("这段原文出现了多次，请加长上下文使其唯一")

        updated = text[:first] + new + text[first + len(old):]
        with open(target, "w", encoding="utf-8") as fh:
            fh.write(updated)
        return self._send(200, {"path": rel(target), "diff": compute_diff(text, updated)})

    def _fs_patch(self, payload):
        """多处改动，一次落盘。

        为什么需要它：改一个文件里的五处，模型要么发五次 edit_file（五个 RTT，
        中间任何一次失败都会留下"改了一半"的文件），要么整篇 write_file
        （把没改的部分也重写一遍，token 和出错面都翻倍）。
        这里先把所有 hunk 在内存里校验并应用，全部成功才写盘。
        """
        target = resolve(payload.get("path"))
        if not os.path.isfile(target):
            raise ValueError("不是文件：%s" % payload.get("path"))
        hunks = payload.get("hunks")
        if not isinstance(hunks, list) or not hunks:
            raise ValueError("hunks 必须是非空数组")
        if os.path.getsize(target) > 4 * 1024 * 1024:
            raise ValueError("文件过大（超过 4 MB），请用 run_shell 处理")

        with open(target, "r", encoding="utf-8", errors="replace") as fh:
            before = fh.read()

        text = before
        applied = 0
        for index, hunk in enumerate(hunks, 1):
            if not isinstance(hunk, dict):
                raise ValueError("第 %d 处不是对象" % index)
            old = hunk.get("old")
            new = hunk.get("new", "")
            if not isinstance(old, str) or not old:
                raise ValueError("第 %d 处缺少 old" % index)
            if not isinstance(new, str):
                raise ValueError("第 %d 处 new 必须是字符串" % index)
            first = text.find(old)
            if first < 0:
                raise ValueError("第 %d 处找不到原文（前 %d 处已校验但未落盘）。原文：%s"
                                 % (index, applied, old.strip().splitlines()[0][:80] if old.strip() else ""))
            if hunk.get("all"):
                text = text.replace(old, new)
                applied += 1
                continue
            if text.find(old, first + 1) >= 0:
                raise ValueError("第 %d 处的原文出现了多次，请加长上下文使其唯一，或设 all=true" % index)
            text = text[:first] + new + text[first + len(old):]
            applied += 1

        with open(target, "w", encoding="utf-8") as fh:
            fh.write(text)
        return self._send(200, {
            "path": rel(target),
            "hunks": applied,
            "diff": compute_diff(before, text),
        })

    # ── 搜索 ─────────────────────────────────────────────────

    def _fs_grep(self, payload):
        """内容搜索。

        不要指望模型自己写对 `grep -rn --include='*.kt' --exclude-dir=.git`：
        GNU grep 与 busybox grep 的参数并不一致，而一个写错的 grep 返回 0 行，
        模型会当成"确实没有"，然后开始凭印象改代码。
        """
        pattern = payload.get("pattern")
        if not isinstance(pattern, str) or not pattern:
            raise ValueError("pattern 必须是非空字符串")
        use_regex = payload.get("regex", True)
        if isinstance(use_regex, str):
            use_regex = use_regex.strip().lower() not in ("false", "0", "no")
        case = bool(payload.get("case"))
        limit = max(1, min(int(payload.get("max", 200) or 200), 1000))
        context = max(0, min(int(payload.get("context", 0) or 0), 5))

        base = resolve(payload.get("path"))
        if not os.path.isdir(base):
            raise ValueError("不是目录：%s" % payload.get("path"))

        name_re = None
        glob = (payload.get("glob") or "").strip()
        if glob:
            name_re = glob_to_regex(glob)

        if use_regex:
            flags = 0 if case else re.IGNORECASE
            try:
                matcher = re.compile(pattern, flags)
            except re.error as exc:
                raise ValueError("正则不合法：%s" % exc)
        else:
            needle = pattern if case else pattern.lower()
            matcher = None

        started = time.time()
        matches = []
        files_scanned = 0
        truncated = False

        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = sorted(d for d in dirnames if d not in DEFAULT_IGNORE)
            for filename in sorted(filenames):
                full = os.path.join(dirpath, filename)
                relative = rel(full)
                if name_re is not None:
                    # 只有当 pattern 里带 `/` 时才按整条相对路径匹配，
                    # 否则 `*.kt` 这种写法会被漏掉（相对路径是 src/a.kt）
                    subject = relative if "/" in glob else filename
                    if not name_re.match(subject):
                        continue
                try:
                    if os.path.getsize(full) > GREP_MAX_FILE:
                        continue
                    with open(full, "rb") as fh:
                        head = fh.read(4096)
                    if b"\x00" in head:
                        continue
                    with open(full, "r", encoding="utf-8", errors="replace") as fh:
                        lines = fh.read().split("\n")
                except (OSError, ValueError):
                    continue
                files_scanned += 1
                for number, line in enumerate(lines, 1):
                    hit = (matcher.search(line) is not None) if matcher else (
                        (needle in line) if case else (needle in line.lower())
                    )
                    if not hit:
                        continue
                    entry = {"path": relative, "line": number, "text": line[:400]}
                    if context:
                        low = max(0, number - 1 - context)
                        high = min(len(lines), number + context)
                        entry["before"] = [s[:400] for s in lines[low:number - 1]]
                        entry["after"] = [s[:400] for s in lines[number:high]]
                    matches.append(entry)
                    if len(matches) >= limit:
                        truncated = True
                        break
                if truncated:
                    break
            if truncated:
                break

        # 按文件聚合，模型读起来比一串扁平行清楚：先看"哪些文件命中"，
        # 再决定读哪个。这和 rg 的输出形态一致。
        grouped = {}
        for match in matches:
            grouped.setdefault(match["path"], []).append(match)

        return self._send(200, {
            "pattern": pattern,
            "files_scanned": files_scanned,
            "matches": matches,
            "files": [{"path": key, "count": len(value)} for key, value in grouped.items()],
            "truncated": truncated,
            "ms": int((time.time() - started) * 1000),
        })

    def _fs_glob(self, payload):
        pattern = payload.get("pattern")
        if not isinstance(pattern, str) or not pattern:
            raise ValueError("pattern 必须是非空字符串")
        limit = max(1, min(int(payload.get("max", 300) or 300), 2000))
        base = resolve(payload.get("path"))
        if not os.path.isdir(base):
            raise ValueError("不是目录：%s" % payload.get("path"))

        matcher = glob_to_regex(pattern)
        by_path = "/" in pattern
        found = []
        truncated = False
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = sorted(d for d in dirnames if d not in DEFAULT_IGNORE)
            for filename in sorted(filenames):
                full = os.path.join(dirpath, filename)
                relative = rel(full)
                subject = relative if by_path else filename
                if not matcher.match(subject):
                    continue
                try:
                    size = os.path.getsize(full)
                except OSError:
                    size = 0
                found.append({"path": relative, "size": size})
                if len(found) >= limit:
                    truncated = True
                    break
            if truncated:
                break
        return self._send(200, {
            "pattern": pattern,
            "count": len(found),
            "paths": found,
            "truncated": truncated,
        })

    def _fs_tree(self, payload):
        """浅层目录树。给模型一个"这个项目长什么样"的总体印象。"""
        base = resolve(payload.get("path"))
        if not os.path.isdir(base):
            raise ValueError("不是目录：%s" % payload.get("path"))
        depth_limit = max(1, min(int(payload.get("depth", 2) or 2), 6))
        budget = max(10, min(int(payload.get("max", 400) or 400), 2000))

        lines = []

        def walk(directory, prefix, depth):
            if len(lines) >= budget:
                return
            try:
                entries = sorted(os.scandir(directory), key=lambda e: (not e.is_dir(), e.name.lower()))
            except OSError:
                return
            for entry in entries:
                if entry.name in DEFAULT_IGNORE:
                    continue
                if len(lines) >= budget:
                    return
                lines.append(prefix + entry.name + ("/" if entry.is_dir() else ""))
                if entry.is_dir() and depth < depth_limit:
                    walk(entry.path, prefix + "  ", depth + 1)

        walk(base, "", 1)
        return self._send(200, {
            "path": rel(base),
            "depth": depth_limit,
            "lines": lines,
            "truncated": len(lines) >= budget,
        })

    def _fs_mkdir(self, payload):
        target = resolve(payload.get("path"))
        os.makedirs(target, exist_ok=True)
        return self._send(200, {"path": rel(target), "ok": True})

    def _fs_stat(self, payload):
        target = resolve(payload.get("path"))
        if not os.path.exists(target):
            return self._send(200, {"exists": False})
        stat = os.stat(target)
        return self._send(200, {
            "exists": True,
            "dir": os.path.isdir(target),
            "size": stat.st_size,
            "mtime": int(stat.st_mtime),
        })

    def _fs_remove(self, payload):
        target = resolve(payload.get("path"))
        if target == ROOT:
            raise ValueError("不允许删除工作区根目录")
        if not os.path.exists(target):
            return self._send(200, {"ok": True, "existed": False})
        if os.path.isdir(target):
            if not payload.get("recursive"):
                os.rmdir(target)
            else:
                shutil.rmtree(target)
        else:
            os.remove(target)
        return self._send(200, {"ok": True, "existed": True})

    def _fs_move(self, payload):
        source = resolve(payload.get("from"))
        destination = resolve(payload.get("to"))
        if not os.path.exists(source):
            raise ValueError("源不存在：%s" % payload.get("from"))
        if os.path.exists(destination) and not payload.get("overwrite"):
            raise ValueError("目标已存在：%s（需要覆盖请传 overwrite=true）" % payload.get("to"))
        os.makedirs(os.path.dirname(destination) or ROOT, exist_ok=True)
        shutil.move(source, destination)
        return self._send(200, {"from": rel(source), "to": rel(destination), "ok": True})

    # ── /fs/upload · /fs/download ────────────────────────────

    def _fs_upload(self):
        """收一段原始字节，落到 `dir/name`。

        参数走 query（`?dir=src&name=a.png`）：请求体整个都是文件内容，
        没有地方再塞 JSON。文件名只取最后一段并挡掉 `..`/分隔符 ——
        否则一个 `name=../../etc/passwd` 就能写出根目录。

        ### `Content-Encoding: gzip`

        客户端带这个头时，请求体是 gzip 压缩过的。两个好处：

        1. **绕开公网网关**。WAF 按明文匹配，上传一个 `.py` 文件的内容
           同样会被判成攻击（实测 `print(1+1)` 就 403）；压缩之后是二进制，
           没有规则能命中。
        2. 大文件传输量直接降一个数量级。

        解压走流式，不把整个文件读进内存；解压后的字节数**也**卡在
        `MAX_UPLOAD` 上，免得一个压缩炸弹把磁盘写满。
        """
        query = parse_qs(urlsplit(self.path).query)
        dir_rel = (query.get("dir") or ["."])[0]
        name = (query.get("name") or [""])[0].strip()
        if not name or name in (".", "..") or "/" in name or "\\" in name or "\x00" in name:
            raise ValueError("文件名非法")
        try:
            length = int(self.headers.get("Content-Length", "0") or "0")
        except ValueError:
            raise ValueError("Content-Length 非法")
        if length <= 0:
            raise ValueError("空文件（0 字节）")
        if length > MAX_UPLOAD:
            raise ValueError("文件太大：%d 字节，上限 %d" % (length, MAX_UPLOAD))

        target_dir = resolve(dir_rel)
        if os.path.exists(target_dir) and not os.path.isdir(target_dir):
            raise ValueError("目标不是目录：%s" % dir_rel)
        os.makedirs(target_dir, exist_ok=True)
        destination = os.path.join(target_dir, name)
        replaced = os.path.exists(destination)

        source = _LimitedReader(self.rfile, length)
        if "gzip" in self.headers.get("Content-Encoding", "").lower():
            source = gzip.GzipFile(fileobj=source, mode="rb")

        # 先写 .part 再 rename：上传中断时不会留下一个看起来正常的半截文件
        partial = destination + ".part"
        written = 0
        try:
            with open(partial, "wb") as fh:
                while True:
                    chunk = source.read(1 << 20)
                    if not chunk:
                        break
                    fh.write(chunk)
                    written += len(chunk)
                    if written > MAX_UPLOAD:
                        raise ValueError("解压后超过上限 %d 字节" % MAX_UPLOAD)
        except Exception:
            try:
                os.remove(partial)
            except OSError:
                pass
            raise
        if written == 0:
            try:
                os.remove(partial)
            except OSError:
                pass
            raise ValueError("传输不完整：收到 0 字节")
        os.replace(partial, destination)
        try:
            os.chmod(destination, 0o644)
        except OSError:
            pass
        return self._send(200, {
            "ok": True,
            "path": rel(destination),
            "name": name,
            "size": written,
            "replaced": replaced,
        })

    def _fs_download(self):
        """把一个文件原样吐回去。分块写，不把大文件读进内存。"""
        query = parse_qs(urlsplit(self.path).query)
        target = resolve((query.get("path") or [""])[0])
        if not os.path.isfile(target):
            return self._send(404, {"error": "文件不存在：%s" % (query.get("path") or [""])[0]})
        size = os.path.getsize(target)
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(size))
        self.send_header(
            "Content-Disposition",
            "attachment; filename*=UTF-8''%s" % quote(os.path.basename(target)),
        )
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        with open(target, "rb") as fh:
            while True:
                chunk = fh.read(1 << 20)
                if not chunk:
                    break
                self.wfile.write(chunk)


def _switch_apt_tuna():
    """把 apt 源换到清华镜像。已经换过就返回 False。

    必须按发行版代号来写：Debian 与 Ubuntu 的源路径不同，硬编码 noble
    在一个 Debian 机器上会把 apt 彻底弄坏 —— 而修它需要另一条命令，
    用户看到的现象是"装不上任何东西"。
    """
    if os.geteuid() != 0:
        return False
    try:
        name, release = "", ""
        with open("/etc/os-release", "r", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("ID="):
                    name = line.split("=", 1)[1].strip().strip('"')
                elif line.startswith("VERSION_CODENAME="):
                    release = line.split("=", 1)[1].strip().strip('"')
                elif line.startswith("UBUNTU_CODENAME=") and not release:
                    release = line.split("=", 1)[1].strip().strip('"')
        if not release:
            return False
        if name == "ubuntu":
            base = "%s/ubuntu/" % TUNA
            lines = [
                "deb %s %s main restricted universe multiverse" % (base, release),
                "deb %s %s-updates main restricted universe multiverse" % (base, release),
                "deb %s %s-backports main restricted universe multiverse" % (base, release),
                "deb %s %s-security main restricted universe multiverse" % (base, release),
            ]
        elif name == "debian":
            base = "%s/debian/" % TUNA
            lines = [
                "deb %s %s main contrib non-free non-free-firmware" % (base, release),
                "deb %s %s-updates main contrib non-free non-free-firmware" % (base, release),
                "deb %s-security/ %s-security main contrib non-free non-free-firmware" % (base, release),
            ]
        else:
            return False
        target = "/etc/apt/sources.list"
        backup = target + ".dsha.bak"
        if os.path.isfile(target) and not os.path.isfile(backup):
            shutil.copy2(target, backup)
        with open(target, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
        # 新版 Ubuntu 用 deb822 格式的 .sources 文件，只改 sources.list 会被它覆盖
        parts = "/etc/apt/sources.list.d"
        if os.path.isdir(parts):
            for item in os.listdir(parts):
                if item.endswith(".sources"):
                    try:
                        os.rename(os.path.join(parts, item), os.path.join(parts, item + ".dsha.bak"))
                    except OSError:
                        pass
        return True
    except OSError:
        return False


def main():
    os.makedirs(ROOT, exist_ok=True)
    ThreadingHTTPServer.daemon_threads = True
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print("=" * 62, flush=True)
    print("DSHA 云端工作区已启动（v2 · 结构化工具）", flush=True)
    print("  监听   : http://0.0.0.0:%d" % PORT, flush=True)
    print("  工作区 : %s" % ROOT, flush=True)
    print("  令牌   : %s" % TOKEN, flush=True)
    print("  工具表 : http://127.0.0.1:%d/tools" % PORT, flush=True)
    print("=" * 62, flush=True)
    print("把【公网地址】和【令牌】两样交给用户，其余不用多说。", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。", flush=True)


if __name__ == "__main__":
    main()
